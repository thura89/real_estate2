<div class="app-wrapper-footer">
    <div class="app-footer">
        <div class="app-footer__inner">
            <div class="app-footer-left">
                <p>Copyright Alright Reserved By Real Estate </p>
            </div>
            <div class="app-footer-right">
                <p>Developed By Green Web Creation</p>
            </div>
        </div>
    </div>
</div><?php /**PATH /Users/Thura/Sites/real_estate2/resources/views/backend/layouts/footer.blade.php ENDPATH**/ ?>