<?php $__env->startSection('title', 'Property Management'); ?>
<?php $__env->startSection('update_property-active', 'mm-active'); ?>
<?php $__env->startSection('extra-css'); ?>
    <link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('/backend/css/image-uploader.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-main__inner">
        <div class="app-page-title">
            <div class="page-title-wrapper">
                <div class="page-title-heading">
                    <div class="page-title-icon">
                        <i class="pe-7s-users icon-gradient bg-mean-fruit">
                        </i>
                    </div>
                    <div>Property Update
                    </div>
                </div>
            </div>
        </div>
        <div class="mb-3">
            <button class="btn btn-primary back-btn"><i class="fas fa-chevron-circle-left"></i> Back</button>
        </div>
        <div class="content">
            <div class="card">
                <div class="card-body">
                    <?php echo $__env->make('backend.layouts.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form action="<?php echo e(route('admin.property.update.house_shop')); ?>" class="form" method="POST"
                        id="update" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="property_category" value="<?php echo e($category); ?>">
                        <input type="hidden" name="property_type" value="<?php echo e($property->properties_type); ?>">
                        <input type="hidden" name="id" value="<?php echo e($id); ?>">
                        
                        <div class="form-group">
                            <h5>Address</h5>
                            <hr>
                            <div class="row">
                                <div class="col form-group">
                                    <label for="region">Region</label>
                                    <?php
                                        $region = $property->address->region()->first('name');
                                    ?>
                                    <span class="region_old badge badge-secondary"><?php echo e($region['name']); ?></span>
                                    <select name="region" class="region form-control">
                                        <option value="">Select Region</option>
                                        <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($region->id); ?>" <?php if(old('region') == $region->id): ?> selected="selected" <?php endif; ?>>
                                                <?php echo e($region->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col form-group">
                                    <label for="township">Township</label>
                                    <?php
                                        $township = $property->address->township()->first('name');
                                    ?>
                                    <span class="township_old badge badge-secondary"><?php echo e($township['name']); ?></span>
                                    <select name="township" class="township form-control">

                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col form-group">
                                    <label for="street_name">Street Name</label>
                                    <input type="text" value="<?php echo e($property->address->street_name); ?>" name="street_name"
                                        class="form-control">
                                </div>
                                <div class="col form-group">
                                    <label for="type_of_street">Type of Street</label>
                                    <select name="type_of_street" class="form-control">
                                        <?php $__currentLoopData = config('const.type_of_street'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $street): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>" <?php if($property->address->type_of_street == $key): ?> selected <?php endif; ?>>
                                                <?php echo e($street); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col form-group">
                                    <label for="ward">Ward</label>
                                    <input value="<?php echo e($property->address->ward); ?>" type="text" name="ward"
                                        class="form-control">
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Area Size</h5>
                            <hr>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="row">
                                        <div class="col-md-6 form-group">
                                            <label for="front_area">Measurement</label>
                                            <select name="measurement" class="form-control">
                                                <?php $__currentLoopData = config('const.area'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($key); ?>" <?php if($property->areasize->measurement == $key): ?> selected <?php endif; ?>>
                                                        <?php echo e($area); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label for="front_area">Front Area</label>
                                            <input value="<?php echo e($property->areasize->front_area); ?>" type="text"
                                                name="front_area" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="row">
                                        <div class="col-md-6 form-group">
                                            <label for="building_width">Building Width</label>
                                            <input value="<?php echo e($property->areasize->building_width); ?>" type="text"
                                                name="building_width" class="form-control">
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label for="building_length">Building Length</label>
                                            <input value="<?php echo e($property->areasize->building_length); ?>" type="text"
                                                name="building_length" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <?php if($category == 1): ?>
                                    <div class="col-md-4">
                                        <div class="row">
                                            <div class="col-md-6 form-group">
                                                <label for="fence_width">Fence Width</label>
                                                <input value="<?php echo e($property->areasize->fence_width); ?>" type="text"
                                                    name="fence_width" class="form-control">
                                            </div>
                                            <div class="col-md-6 form-group">
                                                <label for="fence_length">Fence Length</label>
                                                <input value="<?php echo e($property->areasize->fence_length); ?>" type="text"
                                                    name="fence_length" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="col-md-4 form-group">
                                        <label for="floor_level">Floor Level</label>
                                        <select name="floor_level" class="form-control">
                                            <?php $__currentLoopData = config('const.floor_level'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>" <?php if($property->areasize->level == $key): ?> selected <?php endif; ?>>
                                                    <?php echo e($level); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Partation</h5>
                            <hr>
                            <div class="row">
                                <div class="col-6 col-md-4 form-group">
                                    <label for="width">Partation Type</label>
                                    <select name="partation_type" class="partation_type form-control">
                                        <?php $__currentLoopData = config('const.partation_type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>" <?php if($property->partation->type == $key): ?> selected <?php endif; ?>>
                                                <?php echo e($type); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-6 col-md-4 form-group partation_hider">
                                    <label for="bath_room">Bath Room</label>
                                    <select name="bath_room" class="form-control">
                                        <?php $__currentLoopData = config('const.bath_room'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>" <?php if($property->partation->bath_room == $key): ?> selected <?php endif; ?>>
                                                <?php echo e($room); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-6 col-md-4 form-group partation_hider">
                                    <label for="level">Bed Room</label>
                                    <select name="bed_room" class="form-control">
                                        <?php $__currentLoopData = config('const.bed_room'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>" <?php if($property->partation->bed_room == $key): ?> selected <?php endif; ?>>
                                                <?php echo e($room); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                            </div>
                            <div class="row">
                                <div class="col-6 col-md-4 form-group">
                                    <input name="carpark" type="checkbox" <?php if($property->partation->carpark): ?> checked <?php endif; ?>>
                                    <label for="carpark">Car Park</label>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Property Type</h5>
                            <hr>
                            <div class="row">
                                <div class="col-6 col-md-4 form-group">
                                    <label for="price">Property Type</label>
                                    <select name="property_type" class="property_type form-control" disabled>
                                        <option value="">Select Type</option>
                                        <?php $__currentLoopData = config('const.property_type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $property_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>" <?php if($property->properties_type == $key): ?> selected <?php endif; ?>>
                                                <?php echo e($property_type); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <?php if($property->properties_type == 1): ?>
                            
                            <div class="form-group">
                                <h5>Sale Price</h5>
                                <hr>
                                <div class="row">
                                    <div class="col form-group">
                                        <label for="sale_price">Grand Total Price</label>
                                        <input value="<?php echo e($property->price->price); ?>" type="number" name="sale_price"
                                            class="form-control">
                                    </div>
                                    <div class="col form-group">
                                        <label for="sale_area">Area Type</label>
                                        <select name="sale_area" class="form-control">
                                            <?php $__currentLoopData = config('const.area'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>" <?php if($property->price->area == $key): ?> selected <?php endif; ?>>
                                                    <?php echo e($area); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col form-group">
                                        <label for="sale_price_by_area">Price By Area</label>
                                        <input value="<?php echo e($property->price->price_by_area); ?>" type="text"
                                            name="sale_price_by_area" class="form-control">
                                    </div>
                                    <div class="col form-group">
                                        <label for="sale_currency_code">Currency Code</label>
                                        <select name="sale_currency_code" class="form-control">
                                            <?php $__currentLoopData = config('const.currency_code'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>" <?php if($property->price->currency_code == $key): ?> selected <?php endif; ?>>
                                                    <?php echo e($currency); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            
                            <div class="form-group">
                                <h5>Rent Price</h5>
                                <hr>
                                <div class="row">
                                    <div class="col form-group">
                                        <label for="price">Grand Rent Total Price</label>
                                        <input value="<?php echo e($property->rentprice->price); ?>" type="number" name="price"
                                            class="form-control">
                                    </div>
                                    <div class="col form-group">
                                        <label for="area">Area Type</label>
                                        <select name="area" class="form-control">
                                            <?php $__currentLoopData = config('const.area'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>" <?php if($property->rentprice->area == $key): ?> selected <?php endif; ?>>
                                                    <?php echo e($area); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col form-group">
                                        <label for="price_by_area">Rent Price By Area</label>
                                        <input value="<?php echo e($property->rentprice->price_by_area); ?>" type="number"
                                            name="price_by_area" class="form-control">
                                    </div>
                                    <div class="col form-group">
                                        <label for="currency_code">Currency Code</label>
                                        <select name="currency_code" class="form-control">
                                            <?php $__currentLoopData = config('const.currency_code'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>" <?php if($property->rentprice->currency_code == $key): ?> selected <?php endif; ?>>
                                                    <?php echo e($currency); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col form-group">
                                        <label for="minimun_month">Minimun Month</label>
                                        <select name="minimum_month" class="form-control">
                                            <?php $__currentLoopData = config('const.minimum_month'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>" <?php if($property->rentprice->minimum_month == $key): ?> selected <?php endif; ?>>
                                                    <?php echo e($month); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col form-group">
                                        <label for="rent_pay_type">Pay For Rent Type</label>
                                        value <?php echo e($property->rentprice->rent_pay_type); ?>

                                        <select name="rent_pay_type" class="form-control">
                                            <?php $__currentLoopData = config('const.rent_pay_type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rent_pay_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>" <?php if($property->rentprice->rent_pay_type == $key): ?> selected <?php endif; ?>>
                                                    <?php echo e($rent_pay_type); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col form-group">
                                        <label for="rent_payby_daily">Rent Pay By Daily</label>
                                        <select name="rent_payby_daily" class="form-control">
                                            <?php $__currentLoopData = config('const.rent_payby_daily'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rent_payby_daily): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>" <?php if($property->rentprice->rent_payby_daily == $key): ?> selected <?php endif; ?>>
                                                    <?php echo e($rent_payby_daily); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <div class="form-group">
                            <h5>Payment</h5>
                            <hr>
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label for="area">Purchase Type</label>
                                    <select name="purchase_type" class="form-control">
                                        <?php $__currentLoopData = config('const.purchase_type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $purchase_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>" <?php if($property->payment->purchase_type == $key): ?> selected <?php endif; ?>>
                                                <?php echo e($purchase_type); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                
                                <?php if($property->properties_type == 1): ?>
                                    <div class="col-md-6 form-group">
                                        <label for="">Installment</label>
                                        <fieldset class="position-relative form-group">
                                            <div class="position-relative form-check">
                                                <label class="form-check-label">
                                                    <input name="installment" type="radio" value="1"
                                                        <?php if($property->payment->installment == 1): ?> checked <?php endif; ?> class="form-check-input"> Yes
                                                </label>
                                            </div>
                                            <div class="position-relative form-check">
                                                <label class="form-check-label">
                                                    <input name="installment" type="radio" value="0"
                                                        <?php if($property->payment->installment == 0): ?> checked <?php endif; ?> class="form-check-input"> No
                                                </label>
                                            </div>
                                        </fieldset>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Situation</h5>
                            <hr>
                            <div class="row">
                                <div class="col form-group">
                                    <label for="year_of_construction">Year Of Construction</label>
                                    <select name="year_of_construction" class="form-control">
                                        <?php for($i = (int) date('Y'); $i >= (int) date('Y') - 100; $i--): ?>
                                            <option value='<?php echo e($i); ?>' <?php if($property->situation->year_of_construction == $i): ?> selected <?php endif; ?>>
                                                <?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="col form-group">
                                    <label for="building_repairing">Building Repairing</label>
                                    <select name="building_repairing" class="form-control">
                                        <?php $__currentLoopData = config('const.building_repairing'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $repair): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>" <?php if($property->situation->building_repairing == $key): ?> selected <?php endif; ?>>
                                                <?php echo e($repair); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col form-group">
                                    <label for="building_condition">Building Condition</label>
                                    <select name="building_condition" class="form-control">
                                        <?php $__currentLoopData = config('const.building_condition'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $condition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>" <?php if($property->situation->building_condition == $key): ?> selected <?php endif; ?>>
                                                <?php echo e($condition); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <?php if($category == 1): ?>
                                    <div class="col-md-6 form-group">
                                        <label for="type_of_building">Type Of Building</label>
                                        <input value="<?php echo e($property->situation->type_of_building); ?>" type="text"
                                            name="type_of_building" class="form-control">
                                    </div>
                                <?php else: ?>
                                    <div class="col-md-6 form-group">
                                        <label for="shop_type">Shop Type</label>
                                        <select name="shop_type" class="form-control">
                                            <?php $__currentLoopData = config('const.shop_type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>" <?php if($property->situation->shop_type == $key): ?> selected <?php endif; ?>>
                                                    <?php echo e($type); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Electric & Water Suppliment</h5>
                            <hr>
                            <div class="row">
                                <div class="col form-group">
                                    <label for="">Water Supply</label>
                                    <fieldset class="position-relative form-group">
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input name="water" type="radio" class="form-check-input" value="1"
                                                    <?php if($property->suppliment->water_sys == 1): ?> checked <?php endif; ?>> Yes
                                            </label>
                                        </div>
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input name="water" type="radio" class="form-check-input" value="0"
                                                    <?php if($property->suppliment->water_sys == 0): ?> checked <?php endif; ?>> No
                                            </label>
                                        </div>
                                    </fieldset>
                                </div>
                                <div class="col form-group">
                                    <label for="">Electric Supply</label>
                                    <fieldset class="position-relative form-group">
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input name="electric" type="radio" class="form-check-input" value="1"
                                                    <?php if($property->suppliment->electricity_sys == 1): ?> checked <?php endif; ?>> Yes
                                            </label>
                                        </div>
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input name="electric" type="radio" class="form-check-input" value="0"
                                                    <?php if($property->suppliment->electricity_sys == 0): ?> checked <?php endif; ?>> No
                                            </label>
                                        </div>
                                    </fieldset>
                                </div>
                                <div class="col form-group">
                                    <label for="note">Addition Note</label>
                                    <textarea name="note"
                                        class="form-control"><?php echo e($property->suppliment->note ?? ''); ?></textarea>
                                </div>
                            </div>
                        </div>
                        <?php if($category == 1): ?>
                            
                            <div class="form-group">
                                <h5>Unit Amenities</h5>
                                <hr>
                                <div class="row">
                                    <div class="col form-group">
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input type="checkbox" name="refrigerator" value="1"
                                                    <?php if($property->unitAmenity->refrigerator == 1): ?> checked <?php endif; ?> class="form-check-input">
                                                Refrigerator
                                            </label>
                                        </div>
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input type="checkbox" name="washing_machine" value="1"
                                                    <?php if($property->unitAmenity->washing_machine == 1): ?> checked <?php endif; ?> class="form-check-input">
                                                Washing Machine
                                            </label>
                                        </div>
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input type="checkbox" name="mirowave" value="1" <?php if($property->unitAmenity->mirowave == 1): ?> checked <?php endif; ?>
                                                    class="form-check-input">
                                                Mirowave
                                            </label>

                                        </div>
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input type="checkbox" name="gas_or_electric_stove" value="1"
                                                    <?php if($property->unitAmenity->gas_or_electric_stove == 1): ?> checked <?php endif; ?> class="form-check-input">
                                                Gas or Electric Stove
                                            </label>
                                        </div>
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input type="checkbox" name="air_conditioning" value="1"
                                                    <?php if($property->unitAmenity->air_conditioning == 1): ?> checked <?php endif; ?> class="form-check-input">
                                                Air Conditioning
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col form-group">
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input type="checkbox" name="tv" value="1" <?php if($property->unitAmenity->tv == 1): ?> checked <?php endif; ?>
                                                    class="form-check-input">
                                                TV
                                            </label>
                                        </div>
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input type="checkbox" name="cable_satellite" value="1"
                                                    <?php if($property->unitAmenity->cable_satellite == 1): ?> checked <?php endif; ?> class="form-check-input">
                                                Cable/
                                                Satellite
                                            </label>
                                        </div>
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input type="checkbox" name="internet_wifi" value="1"
                                                    <?php if($property->unitAmenity->internet_wifi == 1): ?> checked <?php endif; ?> class="form-check-input">
                                                Internet
                                                Wifi
                                            </label>
                                        </div>
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input type="checkbox" name="water_heater" value="1"
                                                    <?php if($property->unitAmenity->water_heater == 1): ?> checked <?php endif; ?> class="form-check-input">
                                                WaterHeater
                                            </label>
                                        </div>
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input type="checkbox" name="security_cctv" value="1"
                                                    <?php if($property->unitAmenity->security_cctv == 1): ?> checked <?php endif; ?> class="form-check-input">
                                                Security CCTV
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col form-group">
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input type="checkbox" name="fire_alarm" value="1" <?php if($property->unitAmenity->fire_alarm == 1): ?> checked <?php endif; ?>
                                                    class="form-check-input">
                                                Fire Alarm
                                            </label>
                                        </div>
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input type="checkbox" name="dinning_table" value="1"
                                                    <?php if($property->unitAmenity->dinning_table == 1): ?> checked <?php endif; ?> class="form-check-input">
                                                Dinning
                                                Table
                                            </label>
                                        </div>
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input type="checkbox" name="bed" value="1" <?php if($property->unitAmenity->bed == 1): ?> checked <?php endif; ?>
                                                    class="form-check-input">
                                                Bed
                                            </label>
                                        </div>
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input type="checkbox" name="sofa_chair" value="1" <?php if($property->unitAmenity->sofa_chair == 1): ?> checked <?php endif; ?>
                                                    class="form-check-input">
                                                Sofa
                                                Chair
                                            </label>
                                        </div>
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input type="checkbox" name="private_swimming_pool" value="1"
                                                    <?php if($property->unitAmenity->private_swimming_pool == 1): ?> checked <?php endif; ?> class="form-check-input">
                                                Private Swimming Pool
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if($category == 6): ?>
                            
                            <div class="form-group">
                                <h5>Building Amenities</h5>
                                <hr>
                                <div class="row">
                                    <div class="col form-group">
                                        <div class="position-relative form-check"><label class="form-check-label"><input
                                                    type="checkbox" name="elevator" value="1" class="form-check-input"
                                                    <?php if($property->buildingAmenity->elevator == 1): ?> checked <?php endif; ?>>Elevator</label></div>
                                        <div class="position-relative form-check"><label class="form-check-label"><input
                                                    type="checkbox" name="garage" value="1" class="form-check-input"
                                                    <?php if($property->buildingAmenity->garage == 1): ?> checked <?php endif; ?>>Garage</label></div>
                                        <div class="position-relative form-check"><label class="form-check-label"><input
                                                    type="checkbox" name="fitness_center" value="1"
                                                    class="form-check-input" <?php if($property->buildingAmenity->fitness_center == 1): ?> checked <?php endif; ?>>Fitness
                                                Center</label></div>
                                        <div class="position-relative form-check"><label class="form-check-label"><input
                                                    type="checkbox" name="security" value="1" class="form-check-input"
                                                    <?php if($property->buildingAmenity->security == 1): ?> checked <?php endif; ?>>security</label></div>
                                    </div>
                                    <div class="col form-group">
                                        <div class="position-relative form-check"><label class="form-check-label"><input
                                                    type="checkbox" name="swimming_pool" value="1" class="form-check-input"
                                                    <?php if($property->buildingAmenity->swimming_pool == 1): ?> checked <?php endif; ?>>Swimming Pool</label></div>
                                        <div class="position-relative form-check"><label class="form-check-label"><input
                                                    type="checkbox" name="spa_hot_tub" value="1" class="form-check-input"
                                                    <?php if($property->buildingAmenity->spa_hot_tub == 1): ?> checked <?php endif; ?>>Spa/
                                                Hot Tub</label></div>
                                        <div class="position-relative form-check"><label class="form-check-label"><input
                                                    type="checkbox" name="playground" value="1" class="form-check-input"
                                                    <?php if($property->buildingAmenity->playground == 1): ?> checked <?php endif; ?>>Playground</label></div>
                                        <div class="position-relative form-check"><label class="form-check-label"><input
                                                    type="checkbox" name="garden" value="1" class="form-check-input"
                                                    <?php if($property->buildingAmenity->garden == 1): ?> checked <?php endif; ?>>Garden</label></div>
                                    </div>
                                    <div class="col form-group">
                                        <div class="position-relative form-check"><label class="form-check-label"><input
                                                    type="checkbox" name="carpark " value="1" class="form-check-input"
                                                    <?php if($property->buildingAmenity->carpark == 1): ?> checked <?php endif; ?>>Carpark</label></div>
                                        <div class="position-relative form-check"><label class="form-check-label"><input
                                                    type="checkbox" name="own_transformer" value="1"
                                                    class="form-check-input" <?php if($property->buildingAmenity->own_transformer == 1): ?> checked <?php endif; ?>>Own
                                                Transformer</label></div>
                                        <div class="position-relative form-check"><label class="form-check-label"><input
                                                    type="checkbox" name="disposal" value="1" class="form-check-input"
                                                    <?php if($property->buildingAmenity->disposal == 1): ?> checked <?php endif; ?>>Disposal</label></div>

                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <div class="form-group">
                            <h5>Images</h5>
                            <hr>
                            <div class="input-field">
                                <label class="active">Photos</label>
                                <div class="input-images-2" style="padding-top: .5rem;"></div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-6 col-md-4 form-group">
                                <input name="status" type="checkbox" value="1" <?php if($property->status == 1): ?> checked <?php endif; ?>>
                                <label for="status">Publish This Content</label>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col form-group">
                                <button class="btn btn-secondary back-btn">Back</button>
                                <button type="submit" class="btn btn-primary">Create</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <?php echo JsValidator::formRequest('App\Http\Requests\UpdateHouseRequest', '#update'); ?>

    <?php echo $__env->make('backend.property.rent_script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Thura/Sites/real_estate2/resources/views/backend/property/edit/house_shop.blade.php ENDPATH**/ ?>