<?php $__env->startSection('title', 'Edit want2buyrent Management'); ?>
<?php $__env->startSection('want2buyrent-active', 'mm-active'); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-main__inner">
        <div class="app-page-title">
            <div class="page-title-wrapper">
                <div class="page-title-heading">
                    <div class="page-title-icon">
                        <i class="pe-7s-users icon-gradient bg-mean-fruit">
                        </i>
                    </div>
                    <div>Update Want2BuyRent
                    </div>
                </div>
            </div>
        </div>
        <div class="mb-3">
            <button class="btn btn-primary back-btn"><i class="fas fa-chevron-circle-left"></i> Back</button>
        </div>
        <div class="content">
            <div class="card">
                <div class="card-body">
                    <?php echo $__env->make('backend.developer.layouts.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form action="<?php echo e(route('developer.want2buyrent.update',$data->id)); ?>" id="update"
                        method="POST">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        
                        <div class="form-group">
                            <h5>Info</h5>
                            <hr>
                            <div class="row">
                                <div class="col-6 col-md-6 form-group">
                                    <label for="properties_type">Property Type</label>
                                    <select name="properties_type" class="property_type form-control" disabled>
                                        <option value="">Select Type</option>
                                        <?php $__currentLoopData = config('const.property_type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $property_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>" <?php if($data->properties_type == $key): ?> selected <?php endif; ?>>
                                                <?php echo e($property_type); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-6 col-md-6 form-group">
                                    <label for="properties_category">Property Category</label>
                                    <select name="properties_category" class="property_category form-control" disabled>
                                        <option value="">Select Category</option>
                                        <?php $__currentLoopData = config('const.property_category'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>" <?php if($data->properties_category == $key): ?> selected <?php endif; ?>><?php echo e($category); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6 col-md-6 form-group">
                                    <label for="title">Title</label>
                                    <input type="text" value="<?php echo e($data->title); ?>" name="title" class="form-control">
                                </div>
                                <div class="col-6 col-md-6 form-group">
                                    <label for="phone_no">Phone No</label>
                                    <input type="number" value="<?php echo e($data->phone_no); ?>" name="phone_no" class="form-control">
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Address</h5>
                            <hr>
                            <div class="row">
                                <div class="col form-group">
                                    <label for="region">Region</label>
                                    <?php
                                        $region = $data->region()->first('name');
                                    ?>
                                    <span class="region_old badge badge-secondary"><?php echo e($region['name']); ?></span>
                                    <select name="region" class="region form-control">
                                        <option value="">Select Region</option>
                                        <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($region->id); ?>" <?php if(old('region') == $region->id): ?> selected="selected" <?php endif; ?>>
                                                <?php echo e($region->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col form-group">
                                    <label for="township">Township</label>
                                    <?php
                                        $township = $data->township()->first('name');
                                    ?>
                                    <span class="township_old badge badge-secondary"><?php echo e($township['name']); ?></span>
                                    <select name="township" class="township form-control">

                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Area Size And Condition</h5>
                            <hr>
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="front_area">Measurement</label>
                                    <select name="area_unit" class="form-control">
                                        <?php $__currentLoopData = config('const.area'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"  <?php if($data->area_unit == $key): ?> selected <?php endif; ?>><?php echo e($area); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-md-6 form-group">
                                            <label for="area_width">Width</label>
                                            <input type="text" value="<?php echo e($data->area_width); ?>" name="area_width" class="form-control">
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label for="area_length">Length</label>
                                            <input type="text" value="<?php echo e($data->area_length); ?>" name="area_length" class="form-control">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <?php if($data->properties_category == 3): ?>
                                <div class="col-md-4 hider">
                                    <div class="form-group">
                                        <label for="fence_width">Floor Level</label>
                                        <select name="floor_level" class="form-control">
                                            <option value="">Please Select</option>
                                            <?php $__currentLoopData = config('const.floor_level'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>" <?php if($data->floor_level == $key): ?> selected <?php endif; ?>><?php echo e($level); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4 hider">
                                    <div class="form-group">
                                        <label for="furnished_status">Furnished Status</label>
                                        <select name="furnished_status" class="form-control">
                                            <option value="">Please Select</option>
                                            <?php $__currentLoopData = config('const.furnished_status'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $f_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>" <?php if($data->furnished_status == $key): ?> selected <?php endif; ?>><?php echo e($f_status); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">Completion</label>
                                        <fieldset class="position-relative mt-2 form-group">
                                            <div class="position-relative form-check">
                                                <label class="form-check-label">
                                                    <input name="completion" type="radio" value="1"
                                                    <?php if($data->completion == 1): ?> checked <?php endif; ?> class="form-check-input">
                                                    Complete
                                                </label>
                                                <label class="ml-4 form-check-label">
                                                    <input name="completion" type="radio" value="2"
                                                    <?php if($data->completion == 2): ?> checked <?php endif; ?> class="form-check-input">
                                                    New Launch
                                                </label>
                                            </div>
                                        </fieldset>
                                    </div>
                                </div>

                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Budget Price</h5>
                            <hr>
                            <div class="row">
                                <div class="col form-group">
                                    <label for="budget_from">Budget From</label>
                                    <input type="number" value="<?php echo e($data->budget_from); ?>" name="budget_from" class="form-control">
                                </div>
                                <div class="col form-group">
                                    <label for="budget_to">Budget To</label>
                                    <input type="number" value="<?php echo e($data->budget_to); ?>" name="budget_to" class="form-control">
                                </div>
                                <div class="col form-group">
                                    <label for="currency_code">Currency Code</label>
                                    <select name="currency_code" class="form-control">
                                        <?php $__currentLoopData = config('const.currency_code'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>" <?php if($data->currency_code == $key): ?> selected <?php endif; ?>><?php echo e($currency); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Detail Description</h5>
                            <hr>
                            <div class="row">
                                <div class="col form-group">
                                    <textarea name="descriptions" class="form-control"><?php echo e($data->descriptions); ?></textarea>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Broker</h5>
                            <hr>
                            <div class="row">
                                <div class="col form-group">
                                    <fieldset class="position-relative">
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input <?php if($data->co_broke == 1): ?> checked <?php endif; ?> name="co_broke" type="radio" value="1" class="form-check-input"> Yes
                                            </label>
                                            <label class="ml-4 form-check-label">
                                                <input <?php if($data->co_broke == 0): ?> checked <?php endif; ?> name="co_broke" type="radio" value="0" class="form-check-input"> No
                                            </label>
                                        </div>
                                    </fieldset>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Terms And Condition</h5>
                            <hr>
                            <div class="row">
                                <div class="col-6 col-md-4 form-group">
                                    <input name="terms_condition" <?php if($data->terms_condition == 1): ?> value='1' checked <?php endif; ?> type="checkbox">
                                    <label for="terms_condition">Terms & Condition</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col form-group">
                                    <button class="btn btn-secondary back-btn">Back</button>
                                    <button type="submit" class="btn btn-primary">Create</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <?php echo JsValidator::formRequest('App\Http\Requests\UpdateWant2BuyRentRequest', '#update'); ?>

    <?php echo $__env->make('backend.developer.property.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(document).ready(function() {
            $('.hider').hide();
            $('.property_category').on('change', function() {
                var category = this.value;

                if (category == 3) {
                    $('.hider').show();
                } else {
                    $('.hider').hide();
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.developer.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Thura/Sites/real_estate2/resources/views/backend/developer/want2buyrent/edit.blade.php ENDPATH**/ ?>