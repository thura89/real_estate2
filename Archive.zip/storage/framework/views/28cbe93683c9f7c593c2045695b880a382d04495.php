<?php $__env->startSection('title', 'Property Management'); ?>
<?php $__env->startSection('property-active', 'mm-active'); ?>
<?php $__env->startSection('extra-css'); ?>
    <link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('/backend/css/image-uploader.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-main__inner">
        <div class="app-page-title">
            <div class="page-title-wrapper">
                <div class="page-title-heading">
                    <div class="page-title-icon">
                        <i class="pe-7s-users icon-gradient bg-mean-fruit">
                        </i>
                    </div>
                    <div>Property Create <?php if($category == 1): ?> House <?php else: ?> Shop <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="mb-3">
            <button class="btn btn-primary back-btn"><i class="fas fa-chevron-circle-left"></i> Back</button>
        </div>
        <div class="content">
            <div class="card">
                <div class="card-body">
                    <?php echo $__env->make('backend.developer.layouts.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form action="<?php echo e(route('developer.property.create.house_shop')); ?>" method="POST" id="create"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="property_category" value="<?php echo e($category); ?>">
                        <input type="hidden" name="property_type" value="<?php echo e($type); ?>">
                        
                        <div class="form-group">
                            <h5>Address</h5>
                            <hr>
                            <div class="row">
                                <div class="col form-group">
                                    <label for="region">Region</label>
                                    <select name="region" class="region form-control">
                                        <option value="">Select Region</option>
                                        <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($region->id); ?>" <?php if(old('region') == $region->id): ?> selected="selected" <?php endif; ?>>
                                                <?php echo e($region->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col form-group">
                                    <label for="township">Township</label>
                                    <select name="township" class="township form-control">

                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col form-group">
                                    <label for="street_name">Street Name</label>
                                    <input type="text" name="street_name" class="form-control">
                                </div>
                                <div class="col form-group">
                                    <label for="type_of_street">Type of Street</label>
                                    <select name="type_of_street" class="form-control">
                                        <?php $__currentLoopData = config('const.type_of_street'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $street): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($street); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col form-group">
                                    <label for="ward">Ward</label>
                                    <input type="text" name="ward" class="form-control">
                                </div>
                                <?php if($category == 6): ?>
                                <div class="col form-group">
                                    <label for="building_name">Building Name</label>
                                    <input type="text" name="building_name" class="form-control">
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Area Size</h5>
                            <hr>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="row">
                                        <div class="col-md-6 form-group">
                                            <label for="front_area">Measurement</label>
                                            <select name="measurement" class="form-control">
                                                <?php $__currentLoopData = config('const.area'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($key); ?>"><?php echo e($area); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label for="front_area">Front Area</label>
                                            <input type="text" name="front_area" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="row">
                                        <div class="col-md-6 form-group">
                                            <label for="building_width">Building Width</label>
                                            <input type="text" name="building_width" class="form-control">
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label for="building_length">Building Length</label>
                                            <input type="text" name="building_length" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <?php if($category == 1): ?>
                                <div class="col-md-4">
                                    <div class="row">
                                        <div class="col-md-6 form-group">
                                            <label for="fence_width">Fence Width</label>
                                            <input type="text" name="fence_width" class="form-control">
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label for="fence_length">Fence Length</label>
                                            <input type="text" name="fence_length" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <?php else: ?>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="fence_width">Floor Level</label>
                                        <select name="floor_level" class="form-control">
                                            <option value="">Please Select</option>
                                            <?php $__currentLoopData = config('const.floor_level'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>"><?php echo e($level); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Partation</h5>
                            <hr>
                            <div class="row">
                                <div class="col-6 col-md-4 form-group">
                                    <label for="width">Partation Type</label>
                                    <select name="partation_type" class="partation_type form-control">
                                        <?php $__currentLoopData = config('const.partation_type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($type); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-6 col-md-4 form-group partation_hider">
                                    <label for="bath_room">Bath Room</label>
                                    <select name="bath_room" class="form-control">
                                        <?php $__currentLoopData = config('const.bath_room'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($room); ?>"><?php echo e($room); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-6 col-md-4 form-group partation_hider">
                                    <label for="level">Bed Room</label>
                                    <select name="bed_room" class="form-control">
                                        <?php $__currentLoopData = config('const.bed_room'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($room); ?>"><?php echo e($room); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                            </div>
                            <div class="row">
                                <div class="col-6 col-md-4 form-group">
                                    <input name="carpark" type="checkbox">
                                    <label for="carpark">Car Park</label>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Property Type</h5>
                            <hr>
                            <div class="row">
                                <div class="col-6 col-md-4 form-group">
                                    <label for="price">Property Type</label>
                                    <select name="property_type" class="property_type form-control">
                                        <option value="">Select Type</option>
                                        <?php $__currentLoopData = config('const.property_type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($area); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="price_sale_hider form-group">
                            <h5>Sale Price</h5>
                            <hr>
                            <div class="row">
                                <div class="col form-group">
                                    <label for="sale_price">Grand Total Price</label>
                                    <input type="number" name="sale_price" class="form-control">
                                </div>
                                <div class="col form-group">
                                    <label for="sale_area">Area Type</label>
                                    <select name="sale_area" class="form-control">
                                        <?php $__currentLoopData = config('const.area'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($area); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col form-group">
                                    <label for="sale_price_by_area">Price By Area</label>
                                    <input type="text" name="sale_price_by_area" class="form-control">
                                </div>
                                <div class="col form-group">
                                    <label for="sale_currency_code">Currency Code</label>
                                    <select name="sale_currency_code" class="form-control">
                                        <?php $__currentLoopData = config('const.currency_code'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($currency); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="price_rent_hider form-group">
                            <h5>Rent Price</h5>
                            <hr>
                            <div class="row">
                                <div class="col form-group">
                                    <label for="price">Grand Rent Total Price</label>
                                    <input type="number" name="price" class="form-control">
                                </div>
                                <div class="col form-group">
                                    <label for="area">Area Type</label>
                                    <select name="area" class="form-control">
                                        <?php $__currentLoopData = config('const.area'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($area); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col form-group">
                                    <label for="price_by_area">Rent Price By Area</label>
                                    <input type="number" name="price_by_area" class="form-control">
                                </div>
                                <div class="col form-group">
                                    <label for="currency_code">Currency Code</label>
                                    <select name="currency_code" class="form-control">
                                        <?php $__currentLoopData = config('const.currency_code'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($currency); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col form-group">
                                    <label for="minimum_month">Minimun Month</label>
                                    <select name="minimum_month" class="form-control">
                                        <?php $__currentLoopData = config('const.minimum_month'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($month); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col form-group">
                                    <label for="rent_pay_type">Pay For Rent Type</label>
                                    <select name="rent_pay_type" class="form-control">
                                        <?php $__currentLoopData = config('const.rent_pay_type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rent_pay_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($rent_pay_type); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col form-group">
                                    <label for="rent_payby_daily">Rent Pay By Daily</label>
                                    <select name="rent_payby_daily" class="form-control">
                                        <?php $__currentLoopData = config('const.rent_payby_daily'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rent_payby_daily): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($rent_payby_daily); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Payment</h5>
                            <hr>
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label for="area">Purchase Type</label>
                                    <select name="purchase_type" class="form-control">
                                        <?php $__currentLoopData = config('const.purchase_type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $purchase_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($purchase_type); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col form-group price_sale_hider">
                                    <label for="">Installment</label>
                                    <fieldset class="position-relative form-group">
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input name="installment" type="radio" class="form-check-input"> Yes
                                            </label>
                                        </div>
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input name="installment" type="radio" class="form-check-input"> No
                                            </label>
                                        </div>
                                    </fieldset>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Situation</h5>
                            <hr>
                            <div class="row">
                                <div class="col form-group">
                                    <label for="year_of_construction">Year Of Construction</label>
                                    <select name="year_of_construction" class="form-control">
                                        <?php for($i=(int)date('Y');$i>=((int)date('Y') - 100);$i--): ?>
                                            <option value='<?php echo e($i); ?>'><?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="col form-group">
                                    <label for="building_repairing">Building Repairing</label>
                                    <select name="building_repairing" class="form-control">
                                        <?php $__currentLoopData = config('const.building_repairing'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $repair): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($repair); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col form-group">
                                    <label for="building_condition">Building Condition</label>
                                    <select name="building_condition" class="form-control">
                                        <?php $__currentLoopData = config('const.building_condition'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $condition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($condition); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <?php if($category == 1): ?>
                                <div class="col-md-4 form-group">
                                    <label for="type_of_building">Type Of Building</label>
                                    <input type="text" name="type_of_building" class="form-control">
                                </div>
                                <?php else: ?>
                                <div class="col-md-4 form-group">
                                    <label for="shop_type">Shop Type</label>
                                    <select name="shop_type" class="form-control">
                                        <?php $__currentLoopData = config('const.shop_type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($type); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Electric & Water Suppliment</h5>
                            <hr>
                            <div class="row">
                                <div class="col form-group">
                                    <label for="">Water Supply</label>
                                    <fieldset class="position-relative form-group">
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input name="water" type="radio" value="1" class="form-check-input"> Yes
                                            </label>
                                        </div>
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input name="water" type="radio" value="0" class="form-check-input"> No
                                            </label>
                                        </div>
                                    </fieldset>
                                </div>
                                <div class="col form-group">
                                    <label for="">Electric Supply</label>
                                    <fieldset class="position-relative form-group">
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input name="electric" type="radio" value="1" class="form-check-input"> Yes
                                            </label>
                                        </div>
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input name="electric" type="radio" value="0" class="form-check-input"> No
                                            </label>
                                        </div>
                                    </fieldset>
                                </div>
                                <div class="col form-group">
                                    <label for="">Addition Note</label>
                                    <textarea name="note" class="form-control"></textarea>
                                </div>
                            </div>
                        </div>
                        <?php if($category == 1): ?>
                            
                        <div class="form-group">
                            <h5>Unit Amenities</h5>
                            <hr>
                            <div class="row">
                                <div class="col form-group">
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="refrigerator"
                                                value="1" class="form-check-input">Refrigerator</label></div>
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="washing_machine" value="1" class="form-check-input">Washing
                                            Machine</label></div>
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="mirowave" value="1" class="form-check-input">Mirowave</label>
                                    </div>
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="gas_or_electric_stove" value="1" class="form-check-input">Gas
                                            or Electric Stove</label></div>
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="air_conditioning" value="1" class="form-check-input">Air
                                            Conditioning</label></div>
                                </div>
                                <div class="col form-group">
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="tv" value="1" class="form-check-input">TV</label></div>
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="cable_satellite" value="1" class="form-check-input">Cable/
                                            Satellite</label></div>
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="internet_wifi" value="1" class="form-check-input">Internet
                                            Wifi</label></div>
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="water_heater"
                                                value="1" class="form-check-input">WaterHeater</label></div>
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="security_cctv" value="1" class="form-check-input">Security
                                            CCTV</label></div>
                                </div>
                                <div class="col form-group">
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="fire_alarm" value="1" class="form-check-input">Fire
                                            Alarm</label></div>
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="dinning_table" value="1" class="form-check-input">Dinning
                                            Table</label></div>
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="bed" value="1" class="form-check-input">Bed</label></div>
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="sofa_chair" value="1" class="form-check-input">Sofa
                                            Chair</label></div>
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="private_swimming_pool"
                                                value="1" class="form-check-input">Private Swimming Pool</label></div>
                                </div>
                            </div>
                        </div>
                        <?php else: ?>
                        
                        <div class="form-group">
                            <h5>Building Amenities</h5>
                            <hr>
                            <div class="row">
                                <div class="col form-group">
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="elevator" value="1"
                                                class="form-check-input">Elevator</label></div>
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="garage" value="1"
                                                class="form-check-input">Garage</label></div>
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="fitness_center" value="1"
                                                class="form-check-input">Fitness Center</label></div>
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="Security" value="1"
                                                class="form-check-input">security</label></div>
                                </div>
                                <div class="col form-group">
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="swimming_pool" value="1"
                                                class="form-check-input">Swimming Pool</label></div>
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="spa_hot_tub" value="1" class="form-check-input">Spa/
                                            Hot Tub</label></div>
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="playground" value="1"
                                                class="form-check-input">Playground</label></div>
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="garden" value="1"
                                                class="form-check-input">Garden</label></div>
                                </div>
                                <div class="col form-group">
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="carpark " value="1"
                                                class="form-check-input">Carpark</label></div>
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="own_transformer" value="1"
                                                class="form-check-input">Own Transformer</label></div>
                                    <div class="position-relative form-check"><label class="form-check-label"><input
                                                type="checkbox" name="disposal" value="1"
                                                class="form-check-input">Disposal</label></div>

                                </div>
                            </div>
                        </div> 
                        <?php endif; ?>
                        
                        <div class="form-group">
                            <h5>Images</h5>
                            <hr>
                            <div class="input-field">
                                <label class="active">Photos</label>
                                <div class="input-images-1" style="padding-top: .5rem;"></div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-6 col-md-4 form-group">
                                <input name="status" type="checkbox">
                                <label for="status">Publish This Content</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col form-group">
                                <button class="btn btn-secondary back-btn">Back</button>
                                <button type="submit" class="btn btn-primary">Create</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <?php echo JsValidator::formRequest('App\Http\Requests\HouseSaleRequest', '#create'); ?>

    <?php echo $__env->make('backend.developer.property.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $('.price_sale_hider').hide();
        $('.price_rent_hider').hide();
        $('.property_type').on('change', function(){
            var type = this.value;
            if (type == 1) {
                $('.price_rent_hider').hide();
                $('.price_sale_hider').show();
            }
            if (type == 2) {
                $('.price_sale_hider').hide();
                $('.price_rent_hider').show();
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.developer.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Thura/Sites/real_estate2/resources/views/backend/developer/property/create/house_shop.blade.php ENDPATH**/ ?>