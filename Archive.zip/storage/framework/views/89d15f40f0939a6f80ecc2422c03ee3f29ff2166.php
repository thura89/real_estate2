<?php $__env->startSection('title', 'Property Management'); ?>
<?php $__env->startSection('want2buyrent-active', 'mm-active'); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-main__inner">
        <div class="app-page-title">
            <div class="page-title-wrapper">
                <div class="page-title-heading">
                    <div class="page-title-icon">
                        <i class="pe-7s-users icon-gradient bg-mean-fruit">
                        </i>
                    </div>
                    <div>Create Want2BuyRent
                    </div>
                </div>
            </div>
        </div>
        <div class="mb-3">
            <button class="btn btn-primary back-btn"><i class="fas fa-chevron-circle-left"></i> Back</button>
        </div>
        <div class="content">
            <div class="card">
                <div class="card-body">
                    <?php echo $__env->make('backend.agent.layouts.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form action="<?php echo e(route('agent.want2buyrent.store')); ?>" method="POST" id="create"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        
                        <div class="form-group">
                            <h5>Info</h5>
                            <hr>
                            <div class="row">
                                <div class="col-6 col-md-6 form-group">
                                    <label for="properties_type">Property Type</label>
                                    <select name="properties_type" class="property_type form-control">
                                        <option value="">Select Type</option>
                                        <?php $__currentLoopData = config('const.property_type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $property_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($property_type); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-6 col-md-6 form-group">
                                    <label for="properties_category">Property Category</label>
                                    <select name="properties_category" class="property_category form-control">
                                        <option value="">Select Category</option>
                                        <?php $__currentLoopData = config('const.property_category'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($category); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6 col-md-6 form-group">
                                    <label for="title">Title</label>
                                    <input type="text" name="title" class="form-control">
                                </div>
                                <div class="col-6 col-md-6 form-group">
                                    <label for="phone_no">Phone No</label>
                                    <input type="number" value="<?php echo e(Auth()->user()->phone); ?>" name="phone_no" class="form-control">
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Address</h5>
                            <hr>
                            <div class="row">
                                <div class="col form-group">
                                    <label for="region">Region</label>
                                    <select name="region" class="region form-control">
                                        <option value="">Select Region</option>
                                        <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($region->id); ?>"><?php echo e($region->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col form-group">
                                    <label for="township">Township</label>
                                    <select name="township" class="township form-control">

                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Area Size And Condition</h5>
                            <hr>
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="front_area">Measurement</label>
                                    <select name="area_unit" class="form-control">
                                        <?php $__currentLoopData = config('const.area'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($area); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-md-6 form-group">
                                            <label for="area_width">Width</label>
                                            <input type="text" name="area_width" class="form-control">
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label for="area_length">Length</label>
                                            <input type="text" name="area_length" class="form-control">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 hider">
                                    <div class="form-group">
                                        <label for="fence_width">Floor Level</label>
                                        <select name="floor_level" class="form-control">
                                            <option value="">Please Select</option>
                                            <?php $__currentLoopData = config('const.floor_level'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>"><?php echo e($level); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4 hider">
                                    <div class="form-group">
                                        <label for="furnished_status">Furnished Status</label>
                                        <select name="furnished_status" class="form-control">
                                            <option value="">Please Select</option>
                                            <?php $__currentLoopData = config('const.furnished_status'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $f_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>"><?php echo e($f_status); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">Completion</label>
                                        <fieldset class="position-relative mt-2 form-group">
                                            <div class="position-relative form-check">
                                                <label class="form-check-label">
                                                    <input name="completion" type="radio" value="1"
                                                        class="form-check-input">
                                                    Complete
                                                </label>
                                                <label class="ml-4 form-check-label">
                                                    <input name="completion" type="radio" value="2"
                                                        class="form-check-input">
                                                    New Launch
                                                </label>
                                            </div>
                                        </fieldset>
                                    </div>
                                </div>

                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Budget Price</h5>
                            <hr>
                            <div class="row">
                                <div class="col form-group">
                                    <label for="budget_from">Budget From</label>
                                    <input type="number" name="budget_from" class="form-control">
                                </div>
                                <div class="col form-group">
                                    <label for="budget_to">Budget To</label>
                                    <input type="number" name="budget_to" class="form-control">
                                </div>
                                <div class="col form-group">
                                    <label for="currency_code">Currency Code</label>
                                    <select name="currency_code" class="form-control">
                                        <?php $__currentLoopData = config('const.currency_code'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($currency); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Detail Description</h5>
                            <hr>
                            <div class="row">
                                <div class="col form-group">
                                    <textarea name="descriptions" class="form-control"></textarea>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Broker</h5>
                            <hr>
                            <div class="row">
                                <div class="col form-group">
                                    <fieldset class="position-relative">
                                        <div class="position-relative form-check">
                                            <label class="form-check-label">
                                                <input name="co_broke" type="radio" value="1" class="form-check-input"> Yes
                                            </label>
                                            <label class="ml-4 form-check-label">
                                                <input name="co_broke" type="radio" value="0" class="form-check-input"> No
                                            </label>
                                        </div>
                                    </fieldset>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5>Terms And Condition</h5>
                            <hr>
                            <div class="row">
                                <div class="col-6 col-md-4 form-group">
                                    <input name="terms_condition" type="checkbox">
                                    <label for="terms_condition">Terms & Condition</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col form-group">
                                    <button class="btn btn-secondary back-btn">Back</button>
                                    <button type="submit" class="btn btn-primary">Create</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <?php echo JsValidator::formRequest('App\Http\Requests\CreateWant2BuyRentRequest', '#create'); ?>

    <?php echo $__env->make('backend.agent.property.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(document).ready(function() {
            $('.hider').hide();
            $('.property_category').on('change', function() {
                var category = this.value;

                if (category == 3) {
                    $('.hider').show();
                } else {
                    $('.hider').hide();
                }

            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.agent.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Thura/Sites/real_estate2/resources/views/backend/agent/want2buyrent/create.blade.php ENDPATH**/ ?>