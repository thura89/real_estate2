
<div class="app-sidebar sidebar-shadow">
    <div class="app-header__logo">
        <div class="logo-src"></div>
        <div class="header__pane ml-auto">
            <div>
                <button type="button" class="hamburger close-sidebar-btn hamburger--elastic"
                    data-class="closed-sidebar">
                    <span class="hamburger-box">
                        <span class="hamburger-inner"></span>
                    </span>
                </button>
            </div>
        </div>
    </div>
    <div class="app-header__mobile-menu">
        <div>
            <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                <span class="hamburger-box">
                    <span class="hamburger-inner"></span>
                </span>
            </button>
        </div>
    </div>
    <div class="app-header__menu">
        <span>
            <button type="button"
                class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                <span class="btn-icon-wrapper">
                    <i class="fa fa-ellipsis-v fa-w-6"></i>
                </span>
            </button>
        </span>
    </div>
    <div class="scrollbar-sidebar">
        <div class="app-sidebar__inner">
            <ul class="vertical-nav-menu">
                <li class="app-sidebar__heading">Dashboards</li>
                <li>
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo $__env->yieldContent('dashboard-active'); ?>">
                        <i class="metismenu-icon pe-7s-rocket"></i>
                        Dashboards
                    </a>
                </li>
                <li class="app-sidebar__heading">User Management</li>
                <li>
                    <a href="<?php echo e(route('admin.admin-user.index')); ?>" class="<?php echo $__env->yieldContent('admin-user-active'); ?>">
                        <i class="metismenu-icon pe-7s-diamond"></i>
                        Admin Management
                    </a>
                    <a href="<?php echo e(route('admin.agent-user.index')); ?>" class="<?php echo $__env->yieldContent('agent-user-active'); ?>">
                        <i class="metismenu-icon pe-7s-id"></i>
                        Agent Management
                    </a>
                    <a href="#">
                        <i class="metismenu-icon pe-7s-user"></i>
                        User Management
                    </a>
                  
                </li>
                <li class="app-sidebar__heading">Properties Management</li>
                <li>
                    <a href="<?php echo e(route('admin.property.index')); ?>" class="<?php echo $__env->yieldContent('property-active'); ?>">
                        <i class="metismenu-icon pe-7s-menu"></i>
                        Properties
                    </a>
                    <a href="<?php echo e(route('admin.want2buyrent.index')); ?>" class="<?php echo $__env->yieldContent('want2buyrent-active'); ?>">
                        <i class="metismenu-icon pe-7s-display2"></i>
                        Want2BuyRent
                    </a>
                </li>
                <li class="app-sidebar__heading">News</li>
                <li>
                    <a href="forms-controls.html">
                        <i class="metismenu-icon pe-7s-news-paper">
                        </i>News Management
                    </a>
                </li>
                <li class="app-sidebar__heading">Settings</li>
                <li>
                    <a href="<?php echo e(route('admin.profile')); ?>" class="<?php echo $__env->yieldContent('profile-active'); ?>">
                        <i class="metismenu-icon pe-7s-id"></i>
                        Profile
                    </a>
                    <a href="<?php echo e(route('admin.logout')); ?>"
                        onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                        <i class="metismenu-icon pe-7s-power">
                        </i>Logout
                    </a>
                </li>
              
            </ul>
        </div>
    </div>
</div><?php /**PATH /Users/Thura/Sites/real_estate2/resources/views/backend/layouts/sidebar.blade.php ENDPATH**/ ?>